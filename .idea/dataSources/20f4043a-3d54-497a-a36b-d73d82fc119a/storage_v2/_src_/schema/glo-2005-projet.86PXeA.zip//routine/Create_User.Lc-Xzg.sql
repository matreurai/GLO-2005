create
    definer = root@localhost procedure Create_User(IN id smallint, IN username varchar(20), IN email varchar(40),
                                                   IN phone varchar(20), IN prenom varchar(30), IN nom varchar(40),
                                                   IN date_creation date, IN password varchar(128))
BEGIN
        INSERT INTO `t_utilisateur` (utilisateur_id, utilisateur_username, utilisateur_email, utilisateur_phone, utilisateur_prenom, utilisateur_nom, utilisateur_date_creation)
        VALUES                  (id,
                                username,
                                email,
                                phone,
                                prenom,
                                nom,
                                date_creation);
        INSERT INTO `t_password` (password_id_utilisateur, password_password) VALUES (id, password);
    END;

