create
    definer = root@localhost procedure Create_User(IN username varchar(20), IN email varchar(40), IN date_creation date,
                                                   IN password varchar(128))
BEGIN
        INSERT INTO `t_utilisateur` (utilisateur_username, utilisateur_email, utilisateur_date_creation)
        VALUES                  (username,
                                email,
                                date_creation);
        SELECT @id := LAST_INSERT_ID() FROM `t_utilisateur`;
        INSERT INTO `t_password` (password_id_utilisateur, password_password) VALUES (@id, password);
    END;

